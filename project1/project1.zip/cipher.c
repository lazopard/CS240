#define SHIFT 1 
#define SUBSTITUTION 2 
#define FREQUENCY 3 
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "cipher.h"
#include "fileIO.h"

//DO NOT MODIFY THE HEADERS ABOVE

//SHIFT CIPHER
//
//

void stringToUpper(char * string);

void shift_enc(unsigned char *input, int key, unsigned char *output) {
	//TODO: finish this function
	stringToUpper(input); 
	int i,j,len; 
	len = strlen(input); 
	for(i=0;i < len;i++) {
		for(j =0; j < SIZE_OF_ALPHABET;j++) {
			if (*(input+ i) == (ALPHABET[j])) 
				*(output + i) = ALPHABET[j+key];
		}
	}
}	
	
void shift_dec(unsigned char *input, int key, unsigned char *output) {
	//TODO: finish this function
	stringToUpper(input);
	int i,j,len;
	len = strlen(input);
	for(i=0;i < len;i++) {
		for(j =0; j < SIZE_OF_ALPHABET;j++) {
			if (*(input+ i) == (ALPHABET[j]))
				*(output + i) = ALPHABET[j-key];
		}
	}

}

int findIndex(unsigned char *key, char c, int len);

//BRUTE FORCE ATTACK
//
//
void shift_bf(unsigned char *input, const char *outFilename){
	stringToUpper(input);
	int i,j,len;
	len = strlen(input);
	char *temp;
	char **possibleCombinations;
	for(i=0; i < SIZE_OF_ALPHABET -1 ; i++) {
		for(j=0; j < len; j++) {
			*(temp + j) = ALPHABET[findIndex(ALPHABET ,*(input + j),SIZE_OF_ALPHABET)+ j];
		}
		*(possibleCombinations + i) = temp; 
	}
}

//SUBSTITUTION CIPHER
//
//
int findIndex(unsigned char *key, char c, int len);

void subst_enc(unsigned char *input, unsigned char *alphabet, unsigned char *key, unsigned char *output){
	//TODO: finish this function
	//Given the alphabet "alphabet" and cipher key "key", encrypt the string input using substitution 
	//cipher and write the resulted string to "output". Strings contain the terminator \0
	stringToUpper(input);
	int i,j,input_len,key_len;
	input_len = strlen(input);
	key_len = strlen(key);
	for(i = 0; i < input_len;i++) 
		*(output+i) = key[findIndex(key,*(input+i),key_len)];
	for(i = 0; i < input_len; i++) {
		if ( (*(output+ i) == ' ') && ( *(output+ i + 1) != ' ') ) 
			*(output+ i ) = *(output+ i + 1);
	}
}

void subst_dec(unsigned char *input, unsigned char *alphabet, unsigned char *key, unsigned char *output){
	//TODO: finish this function
	stringToUpper(input);
	int i,j,input_len,key_len,alphabet_len;
	input_len = strlen(input);
	key_len = strlen(key);
	alphabet_len = strlen(alphabet);
	for(i = 0; i < input_len;i++) 
		*(output+i) = key[findIndex(alphabet,*(input+i),alphabet_len)];
}

/**
 * Frequency Analysis
 *
 * outFilename - the file to write output to.
 * Input data ends with a ‘\0’ terminator.
 */
typedef struct {
	char c;
	double freq;
} charFreq;

void stringToUpper(char *string);

int compareDouble(double a, double b);

void charFreqSort(charFreq *charsFreq, int len);

void analyzeFreq(unsigned char *input, const char *outFilename) {
	
	int i,len,j;
	charFreq charsFreq[SIZE_OF_ALPHABET];
	charFreq stdFreq[SIZE_OF_ALPHABET];
	for(i=0;i < SIZE_OF_ALPHABET;i++) {
		charsFreq[i].freq = 0;
		charsFreq[i].c = ALPHABET[i];
		stdFreq[i].freq = freq[i];
		stdFreq[i].c = ALPHABET[i];
	}
	len = strlen(input);
	for(i=0;i < len; i++) {
		for(j=0;j < SIZE_OF_ALPHABET;j++) {
			if (*(input + i) == ALPHABET[i] )
				charsFreq[j].freq++;
		}
	}
	for(i=0;i < SIZE_OF_ALPHABET; i++) {
		charsFreq[i].freq = charsFreq[i].freq / (double)len;
	}
	charFreqSort(charsFreq,SIZE_OF_ALPHABET);
	charFreqSort(stdFreq,SIZE_OF_ALPHABET);
	// Write the file header to the output file.
	printFile(outFilename, DISCARD_CONTENT, "Frequency\t\t\tLetter\t\t\tPredict\t\t\tStd Freq\n");
	for(i =0; i < SIZE_OF_ALPHABET;i++)
		printFile(outFilename, DISCARD_CONTENT, "%.6f\t\t\t%c\t\t\t%c\t\t\t%.6f\n",charsFreq[i].freq,charsFreq[i].c,stdFreq[i].c,stdFreq[i].freq);
	//TODO: finish this function
}

//MAIN FUNCTION

int argumentsAreValid(int foundInput, int foundOutput,
						int foundEncription, int foundDecription);

int main(int argc, char ** argv) {
	int i,foundInput,foundOutput,foundEncription,foundDecription;
	i=foundInput=foundOutput=foundEncription=foundDecription=0;
	char *inputFile = NULL;
	char *outputFile = NULL;
	char *input = "-i";
	char *output = "-o";
	char *decription = "-d=";
	char *encription = "-e=";
	for(i = 1; i < argc; i++) {
		if (!strcmp(argv[i], input)) {
			foundInput++;
			inputFile = argv[i+1];
		}
		if (!strcmp(argv[i], output)) {
			foundOutput++;
			outputFile = argv[i+1];
		}
		if (!strncmp(argv[i],decription,2)) {
			foundDecription++;	
		}
		if (!strncmp(argv[i],encription,2)) {
			foundEncription++;	
		}
		printf("input %d, output %d, d %d, e %d\n",foundInput,foundOutput,foundDecription,foundEncription);
	}
	if (argumentsAreValid(foundInput,foundOutput,foundEncription,foundDecription)) {
		printf("arguments are valid\n");
			
		
		freeMem();
		return 0;
	}
	else  {
		printf("Invalid argument usage.\n");
		return 1;
	}
}

int argumentsAreValid(int foundInput, int foundOutput,
						int foundEncription, int foundDecription) {
	if (foundInput >= 2 || foundOutput >= 2 || foundEncription >= 2 || foundDecription >= 2)
		return 0;
	if (!(foundInput || foundOutput))
		return 0;
	if ( (foundDecription && foundEncription) || (!(foundDecription || foundEncription))) 
		return 0;
	return 1; 	
}

void charFreqSort(charFreq *charsFreq, int len) {
	//Not the fastest but good enough for only 26 elements
	int i,j;
	charFreq temp;
	for(i=0; i < len; i++) {
		for(j=0;j < len;j++) {
			if (compareDouble(charsFreq[i].freq, charsFreq[j].freq)) {
				temp.c = charsFreq[i].c;
				temp.freq = charsFreq[i].freq;
				*(charsFreq + i) = *(charsFreq + j);
				*(charsFreq + j) = temp;
			}
		}
	}
}

int compareDouble(double a, double b) { 
	if ((a - b) > 0.0 )
		return 1;
	else if ((a-b) == 0.0)
		return -1;
	else
		return 0;
}

int findIndex(unsigned char *key, char c, int len) {
	int i;
	for(i = 0; i< len; i++) {
		if (c == *(key + i)) {
			return i; }
	}
	return -1;
}

void stringToUpper(char * string) {
	int i, len;
	len = strlen(string);
	for(i=0; i<len;i++) 
		*(string) = toupper(*string+i);
}
