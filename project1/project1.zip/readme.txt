To compile with libfileIO.a under 64-bit Linux:
	add -m32 flag

Here is some statistical info about the letters in sample.txt:

Total	644036
A	50473
B	10561
C	15856
D	27228
E	82932
F	13998
G	12562
H	41438
I	45336
J	1019
K	4366
L	26300
M	16868
N	44697
O	48180
P	9750
Q	836
R	37729
S	39608
T	57327
U	18453
V	6571
W	14978
X	987
Y	14969
Z	1014
