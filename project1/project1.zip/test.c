#define SHIFT 1 
#define SUBSTITUTION 2 
#define FREQUENCY 3 
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "cipher.h"
#include "fileIO.h"


